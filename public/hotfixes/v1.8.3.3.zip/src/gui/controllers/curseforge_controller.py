from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Signal, Slot

from mcw_core.api.language.language_manager import tr

from mcw_core.api.curseforge.curseforge_client import CurseForgeClient
from mcw_core.api.curseforge.curseforge_manual_installer import CurseForgeManualInstaller
from mcw_core.api.curseforge.curseforge_mod_installer import CurseForgeModInstaller
from mcw_core.api.curseforge.curseforge_errors import CurseForgeModpackManualDownloadRequired
from mcw_core.api.curseforge.curseforge_pack_installer import CurseForgePackInstaller
from mcw_core.api.instance.instance_manager import InstanceManager
from mcw_core.api.progress.progress_reporter import ProgressReporter
from src.gui.controllers.base_controller import BaseController
from src.gui.task_runner import TaskRunner
from mcw_core.api.models.curseforge.cache import CurseForgeFileListResult
from mcw_core.api.models.curseforge.manual_download import CurseForgeManualDownload


class CurseForgeController(BaseController):
    search_results_changed = Signal(str, str, object)
    files_changed = Signal(str, int, str, list)
    project_details_changed = Signal(str, int, str, object)
    cache_info_changed = Signal(str, object)
    catalog_search_results_changed = Signal(str, object)
    catalog_files_changed = Signal(int, str, list)
    catalog_cache_info_changed = Signal(object)
    catalog_request_failed = Signal(str, str, str)
    mod_installed = Signal(object)
    manual_file_installed = Signal(str, object, str)
    manual_files_installed = Signal(str, object)
    modpack_installed = Signal(object)
    modpack_manual_download_required = Signal(object)
    cache_cleared = Signal(object)
    progress_received = Signal(object)

    DIALOG_CONTEXT = "dialog"
    CATALOG_CONTEXT = "catalog"

    def __init__(self, task_runner: TaskRunner) -> None:
        super().__init__()
        self._task_runner = task_runner
        self._task_runner.task_succeeded.connect(self._on_task_succeeded)
        self._task_runner.task_failed.connect(self._on_task_failed)

    def search(self, project_type: str, query: str, sort: str, index: int, game_version: str = "", loader: str = "forge", force_refresh: bool = False, manual_refresh: bool = False, context: str = DIALOG_CONTEXT) -> bool:
        normalized_context = self._normalize_context(context)
        normalized_loader = CurseForgeClient.normalize_loader(loader) or "forge"
        task_id = f"curseforge.search.{normalized_context}.{project_type}.{normalized_loader}"
        task = lambda: (
            normalized_context,
            project_type,
            normalized_loader,
            CurseForgeClient.search_projects(
                project_type=project_type,
                query=query,
                game_version=game_version,
                loader=normalized_loader,
                index=index,
                page_size=25,
                sort=sort,
                force_refresh=force_refresh,
                manual_refresh=manual_refresh,
            ),
        )
        return self._run_network_task(
            self._task_runner,
            task_id,
            task,
            tr("task.curseforge.search", project_type=project_type),
            blocking=False,
        )

    def load_project_details(self, project_type: str, project_id: int, loader: str = "forge") -> bool:
        normalized_loader = CurseForgeClient.normalize_loader(loader) or "forge"
        task_id = f"curseforge.details.{project_type}.{project_id}.{normalized_loader}"
        task = lambda: (project_type, int(project_id), normalized_loader, CurseForgeClient.get_project_details(project_id))
        return self._run_network_task(
            self._task_runner,
            task_id,
            task,
            tr("task.curseforge.load_project_details"),
            blocking=False,
            group=f"curseforge.details.{project_type}",
        )

    def load_files(self, project_type: str, project_id: int, game_version: str, loader: str, allowed_release_types: tuple[str, ...], force_refresh: bool = False, manual_refresh: bool = False, context: str = DIALOG_CONTEXT) -> bool:
        normalized_context = self._normalize_context(context)
        normalized_loader = CurseForgeClient.normalize_loader(loader) or "forge"
        task_id = f"curseforge.files.{normalized_context}.{project_type}.{project_id}.{normalized_loader}"
        task = lambda: (
            normalized_context,
            project_type,
            int(project_id),
            normalized_loader,
            CurseForgeClient.list_files_result(
                project_id,
                game_version=game_version,
                loader=normalized_loader,
                release_types=allowed_release_types,
                page_size=50,
                force_refresh=force_refresh,
                manual_refresh=manual_refresh,
            ),
        )
        return self._run_network_task(
            self._task_runner,
            task_id,
            task,
            tr("task.curseforge.load_compatible_files"),
            blocking=False,
            group=f"curseforge.files.{normalized_context}.{project_type}",
        )

    def install_mod(self, instance_name: str, project_id: int, file_id: int, allowed_release_types: tuple[str, ...], allow_unverified: bool = False) -> bool:
        reporter = ProgressReporter(self.progress_received.emit)

        def task() -> object:
            instance = InstanceManager.load(instance_name)
            return CurseForgeModInstaller.install(
                instance,
                project_id,
                file_id,
                install_dependencies=True,
                allowed_release_types=allowed_release_types,
                reporter=reporter,
                allow_unverified=allow_unverified,
            )

        return self._task_runner.run("curseforge.install.mod", task, tr("task.curseforge.install_mod", instance=instance_name), blocking=False)

    def install_manual_file(self, instance_name: str, requirement: CurseForgeManualDownload, source: Path, launch_lock_token: str | None = None) -> bool:
        task_id = f"curseforge.install.manual.{requirement.project_id}"
        return self._task_runner.run(
            task_id,
            lambda: (
                instance_name,
                requirement,
                CurseForgeManualInstaller.install(InstanceManager.load(instance_name), requirement, source, launch_lock_token=launch_lock_token),
            ),
            tr("task.curseforge.import_manual_file", file=requirement.file_name),
            blocking=False,
        )

    def install_manual_files(self, instance_name: str, requirements: tuple[CurseForgeManualDownload, ...] | list[CurseForgeManualDownload], sources: tuple[Path, ...] | list[Path], launch_lock_token: str | None = None) -> bool:
        normalized_sources = [Path(source) for source in sources]
        if not normalized_sources:
            return False
        task_id = "curseforge.install.manual.batch"
        return self._task_runner.run(
            task_id,
            lambda: (
                instance_name,
                CurseForgeManualInstaller.install_many(InstanceManager.load(instance_name), requirements, normalized_sources, launch_lock_token=launch_lock_token),
            ),
            tr("task.curseforge.add_downloaded_files", count=len(normalized_sources), instance=instance_name),
            blocking=False,
        )

    def install_modpack(self, project_id: int, file_id: int, instance_name: str, install_optional_files: bool, allowed_release_types: tuple[str, ...], expected_loader: str = "", settings_override: dict | None = None) -> bool:
        reporter = ProgressReporter(self.progress_received.emit)
        return self._task_runner.run(
            "curseforge.install.modpack",
            lambda: CurseForgePackInstaller.install(
                project_id,
                file_id,
                instance_name,
                install_optional_files=install_optional_files,
                allowed_release_types=allowed_release_types,
                reporter=reporter,
                expected_loader=expected_loader,
                settings_override=settings_override,
            ),
            tr("task.curseforge.install_modpack", instance=instance_name),
        )

    def install_manual_modpack(self, request: CurseForgeModpackManualDownloadRequired, source: Path) -> bool:
        reporter = ProgressReporter(self.progress_received.emit)
        return self._task_runner.run(
            "curseforge.install.modpack.manual",
            lambda: CurseForgePackInstaller.install_manual_archive(request, Path(source), reporter=reporter),
            tr("task.curseforge.install_downloaded_modpack", instance=request.instance_name),
        )

    def clear_api_cache(self, context: str = DIALOG_CONTEXT) -> bool:
        normalized_context = self._normalize_context(context)
        return self._task_runner.run(
            f"curseforge.cache.clear.{normalized_context}",
            lambda: (normalized_context, (CurseForgeClient.clear_api_cache(), CurseForgeClient.api_cache_status())[1]),
            tr("task.curseforge.clear_cache"),
            blocking=False,
        )

    def clear_cache(self, context: str = DIALOG_CONTEXT) -> bool:
        """Compatibility alias for clearing the provider API metadata cache."""
        return self.clear_api_cache(context=context)

    @Slot(str, object)
    def _on_task_succeeded(self, task_id: str, result: object) -> None:
        if task_id.startswith("curseforge.search."):
            if not isinstance(result, tuple) or len(result) != 4:
                self._emit_error("CurseForge", "CurseForge search returned an invalid result.")
                return
            context, project_type, loader, search_result = result
            if context == self.CATALOG_CONTEXT:
                self.catalog_search_results_changed.emit(str(loader), search_result)
                self.catalog_cache_info_changed.emit(getattr(search_result, "cache_info", CurseForgeClient.api_cache_status()))
            else:
                self.search_results_changed.emit(str(project_type), str(loader), search_result)
                self.cache_info_changed.emit(str(project_type), getattr(search_result, "cache_info", CurseForgeClient.api_cache_status()))
            return
        if task_id.startswith("curseforge.details."):
            if not isinstance(result, tuple) or len(result) != 4:
                self._emit_error("CurseForge", "CurseForge project details returned an invalid result.")
                return
            project_type, project_id, loader, project = result
            self.project_details_changed.emit(str(project_type), int(project_id), str(loader), project)
            return
        if task_id.startswith("curseforge.files."):
            if not isinstance(result, tuple) or len(result) != 5:
                self._emit_error("CurseForge", "CurseForge files returned an invalid result.")
                return
            context, project_type, project_id, loader, file_result = result
            if not isinstance(file_result, CurseForgeFileListResult):
                self._emit_error("CurseForge", "CurseForge files returned an invalid cache result.")
                return
            if context == self.CATALOG_CONTEXT:
                self.catalog_files_changed.emit(int(project_id), str(loader), list(file_result.files))
                self.catalog_cache_info_changed.emit(file_result.cache_info)
            else:
                self.files_changed.emit(str(project_type), int(project_id), str(loader), list(file_result.files))
                self.cache_info_changed.emit(str(project_type), file_result.cache_info)
            return
        if task_id == "curseforge.install.mod":
            self.status_changed.emit(tr("status.curseforge.mod_installed"))
            self.log_created.emit("Installed CurseForge mod and required dependencies")
            self.mod_installed.emit(result)
            return
        if task_id == "curseforge.install.manual.batch":
            if isinstance(result, tuple) and len(result) == 2:
                instance_name, batch_result = result
                self.manual_files_installed.emit(str(instance_name), batch_result)
                self.status_changed.emit(tr("status.curseforge.downloaded_files_added"))
                imported_count = len(getattr(batch_result, "imported", ()) or ())
                extra_count = len(getattr(batch_result, "added_mods", ()) or ())
                self.log_created.emit(f"Added downloaded mod files: {imported_count} required, {extra_count} additional")
            return
        if task_id.startswith("curseforge.install.manual."):
            if isinstance(result, tuple) and len(result) == 3:
                instance_name, requirement, installed_name = result
                self.manual_file_installed.emit(str(instance_name), requirement, str(installed_name))
                self.status_changed.emit(tr("status.curseforge.manual_file_imported"))
                self.log_created.emit(f"Imported manually downloaded CurseForge file: {installed_name}")
            return
        if task_id in {"curseforge.install.modpack", "curseforge.install.modpack.manual"}:
            self.status_changed.emit(tr("status.curseforge.modpack_installed"))
            instance = getattr(result, "instance", None)
            loader, _version = getattr(instance, "mod_loader", ("unknown", ""))
            self.log_created.emit(f"Created {str(loader).title()} instance from CurseForge modpack")
            self.modpack_installed.emit(result)
            return
        if task_id.startswith("curseforge.cache.clear."):
            if not isinstance(result, tuple) or len(result) != 2:
                self._emit_error("CurseForge", "CurseForge cache clear returned an invalid result.")
                return
            context, info = result
            self.cache_cleared.emit(info)
            if context == self.CATALOG_CONTEXT:
                self.catalog_cache_info_changed.emit(info)
            else:
                self.cache_info_changed.emit("mod", info)
                self.cache_info_changed.emit("modpack", info)
            self.status_changed.emit(tr("status.curseforge.cache_cleared"))

    @Slot(str, object)
    def _on_task_failed(self, task_id: str, error: Exception) -> None:
        if not task_id.startswith("curseforge."):
            return

        if task_id == "curseforge.install.mod":
            title = tr("curseforge.mod.install")
        elif task_id.startswith("curseforge.install.manual."):
            title = tr("curseforge.manual.title")
        elif task_id in {"curseforge.install.modpack", "curseforge.install.modpack.manual"}:
            title = tr("curseforge.modpack.install")
        else:
            title = tr("curseforge.title")

        if task_id.startswith("curseforge.details."):
            self.log_created.emit(f"Could not load CurseForge project details: {error}")
            self._offer_network_retry(task_id, title, error)
            return

        if task_id.startswith("curseforge.search.catalog."):
            loader = task_id.rsplit(".", 1)[-1]
            self.catalog_request_failed.emit("search", loader, str(error) or "CurseForge search failed.")
            if self._offer_network_retry(task_id, title, error):
                return
            return

        if task_id.startswith("curseforge.files.catalog."):
            parts = task_id.split(".")
            project_id = parts[-2] if len(parts) >= 2 else "0"
            loader = parts[-1] if parts else ""
            self.catalog_request_failed.emit(f"files:{project_id}", loader, str(error) or "CurseForge files request failed.")
            if self._offer_network_retry(task_id, title, error):
                return
            return

        if task_id.startswith("curseforge.cache.clear.catalog"):
            self.catalog_request_failed.emit("cache", "", str(error) or "Could not clear CurseForge cache.")
            return

        if task_id == "curseforge.install.modpack" and isinstance(error, CurseForgeModpackManualDownloadRequired):
            self.status_changed.emit(tr("status.curseforge.manual_download_required"))
            self.log_created.emit(str(error))
            self.modpack_manual_download_required.emit(error)
            return

        if self._offer_network_retry(task_id, title, error):
            return
        self._emit_error(title, error)

    @classmethod
    def _normalize_context(cls, context: str) -> str:
        normalized = str(context or cls.DIALOG_CONTEXT).strip().lower()
        return normalized if normalized in {cls.DIALOG_CONTEXT, cls.CATALOG_CONTEXT} else cls.DIALOG_CONTEXT
