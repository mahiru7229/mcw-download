from src.gui.dark_theme_constants import FORCED_DARK_APPLICATION_STYLE


APP_STYLE = """
QWidget {
    color: #ffffff;
    font-size: 10.5pt;
}

QMainWindow, QWidget#Root {
    background: #171817;
}

QDialog {
    background: #252823;
    color: #ffffff;
}

QMessageBox {
    background: #20221f;
    color: #ffffff;
}

QMessageBox QLabel, QMessageBox QTextEdit {
    background: transparent;
    color: #ffffff;
}

QMessageBox QPushButton {
    min-width: 88px;
    background: #343730;
    color: #ffffff;
    border-color: #596451;
}

QMessageBox QPushButton:hover {
    background: #454940;
    color: #ffffff;
}

QFrame#Sidebar {
    background: #20221f;
    border-right: 3px solid #11120f;
}

QWidget#CenterArea {
    background: #2b2d29;
}

QStackedWidget#ContentStack, QScrollArea, QWidget#PageViewport {
    background: #2b2d29;
    border: none;
}

QFrame#RightPanel {
    background: #252723;
    border-left: 3px solid #11120f;
}



QFrame#InstanceToolbar {
    background: #242722;
    border: 2px solid #11120f;
    border-bottom-color: #0b0c0a;
}

QFrame#InstanceLibrary {
    background: #262923;
    border: 2px solid #151713;
}

QFrame#InstanceActionPanel {
    background: #343730;
    border: 2px solid #161713;
    border-bottom-color: #0d0e0c;
    border-right-color: #0d0e0c;
}

QFrame#InstanceActionPanel QPushButton {
    padding: 4px 12px;
}

QFrame#InstanceActionPanel QPushButton#PrimaryButton,
QFrame#InstanceActionPanel QPushButton#SecondaryButton {
    padding: 6px 14px;
}

QFrame#CompactProgressWidget {
    background: #252822;
    border: 2px solid #161713;
    border-radius: 4px;
}

QLabel#ProgressMetricLabel {
    color: #e0e6db;
    font-size: 8.5pt;
    font-weight: 600;
}

QLabel#ProgressDetailLabel {
    color: #f0f4ec;
    font-size: 8.5pt;
    font-weight: 500;
}

QListWidget#InstanceLibraryList {
    background: #20221f;
    color: #ffffff;
    border: 2px solid #11120f;
    outline: none;
    padding: 6px;
}

QListWidget#InstanceLibraryList::item {
    background: #2d302b;
    color: #ffffff;
    border: 2px solid #161713;
    padding: 8px;
    margin: 3px;
}

QListWidget#InstanceLibraryList::item:hover {
    background: #3a3f36;
    border-color: #56674a;
}

QListWidget#InstanceLibraryList::item:selected {
    background: #435538;
    border: 3px solid #83b75f;
    color: #ffffff;
}

QListWidget#InstanceEditorNavigation {
    background: #20221f;
    color: #ffffff;
    border: 2px solid #11120f;
    outline: none;
    padding: 5px;
}

QListWidget#InstanceEditorNavigation::item {
    padding: 10px 12px;
    border: 2px solid transparent;
}

QListWidget#InstanceEditorNavigation::item:hover {
    background: #2e312b;
    border-color: #161713;
}

QListWidget#InstanceEditorNavigation::item:selected {
    background: #3d4c32;
    border-color: #83b75f;
}

QSplitter#InstanceWorkspaceSplitter::handle {
    background: #11120f;
    width: 4px;
}

QFrame#LaunchControl {
    background: #1e201d;
    border-top: 3px solid #11120f;
}

QFrame#Card {
    background: #343730;
    border: 2px solid #161713;
    border-bottom-color: #0d0e0c;
    border-right-color: #0d0e0c;
}

QFrame#HeroCard {
    background: #30342d;
    border: 3px solid #151713;
}

QFrame#InsetPanel {
    background: #262923;
    border: 2px solid #151713;
}

QLabel#BrandLabel {
    color: #ffffff;
    font-size: 22px;
    font-weight: 900;
    letter-spacing: 0.5px;
}

QLabel#VersionLabel, QLabel#MutedLabel {
    color: #ffffff;
}

QLabel#PageTitle {
    color: #ffffff;
    font-size: 27px;
    font-weight: 800;
}

QLabel#PageSubtitle {
    color: #ffffff;
    font-size: 11pt;
}

QLabel#SectionTitle {
    color: #ffffff;
    font-size: 18px;
    font-weight: 900;
    padding-top: 4px;
}

QLabel#SectionSubtitle {
    color: #d7d7d7;
    font-size: 10pt;
}

QLabel#CardTitle {
    color: #ffffff;
    font-size: 14px;
    font-weight: 800;
}

QLabel#CardSubtitle {
    color: #ffffff;
}

QLabel#ValueLabel {
    color: #ffffff;
    font-size: 12pt;
    font-weight: 700;
}

QLabel#TinyLabel {
    color: #ffffff;
    font-size: 9pt;
}

QLabel#StatusBadge {
    background: #344329;
    color: #ffffff;
    border: 2px solid #12140f;
    padding: 6px 10px;
    font-weight: 800;
}

QLabel#WarningBadge {
    background: #4a3824;
    color: #ffffff;
    border: 2px solid #15120e;
    padding: 6px 10px;
    font-weight: 800;
}

QLabel#ConnectivityBadge {
    background: #30352d;
    color: #ffffff;
    border: 1px solid #171a15;
    padding: 4px 9px;
    font-weight: 700;
}

QLabel#ConnectivityBadge[connectivityState="online"] {
    background: #344329;
}

QLabel#ConnectivityBadge[connectivityState="offline"] {
    background: #4a3824;
}

QPushButton {
    background: #454940;
    color: #ffffff;
    border: 2px solid #171814;
    border-bottom-color: #0c0d0b;
    border-right-color: #0c0d0b;
    padding: 8px 12px;
    font-weight: 700;
}

QPushButton:hover {
    background: #565c4e;
    color: #ffffff;
}

QPushButton:pressed {
    background: #30332d;
    border-top-color: #0c0d0b;
    border-left-color: #0c0d0b;
    border-bottom-color: #171814;
    border-right-color: #171814;
}

QPushButton:disabled {
    background: #30322e;
    color: #ffffff;
    border-color: #1d1e1b;
}

QPushButton#PrimaryButton {
    background: #63984a;
    color: #ffffff;
    border: 3px solid #11150e;
    font-size: 13pt;
    font-weight: 900;
}

QPushButton#PrimaryButton:hover {
    background: #7db45e;
    color: #ffffff;
}


QLabel#UnsavedChangesBanner {
    background: #5a421d;
    color: #ffffff;
    border: 2px solid #d6a93c;
    border-radius: 4px;
    padding: 6px 12px;
    font-weight: 900;
}


QFrame#FloatingSettingsBar {
    background: rgba(28, 31, 26, 244);
    border: 2px solid #454d3e;
    border-radius: 6px;
}

QFrame#FloatingSettingsBar[unsavedChanges="true"] {
    background: rgba(42, 34, 21, 250);
    border: 2px solid #d6a93c;
}

QPushButton#PrimaryButton[unsavedChanges="true"] {
    background: #d6a93c;
    color: #ffffff;
    border: 3px solid #fff0a8;
}

QPushButton#PrimaryButton[unsavedChanges="true"]:hover {
    background: #edc95f;
    color: #ffffff;
}

QPushButton#NavButton[unsavedChanges="true"] {
    background: #5a421d;
    color: #ffffff;
    border-color: #d6a93c;
    font-weight: 900;
}

QPushButton#NavButton[unsavedChanges="true"]:checked {
    background: #6b5124;
    color: #ffffff;
    border-color: #edc95f;
}

QPushButton#DangerButton {
    background: #6e3937;
    color: #ffffff;
}

QPushButton#DangerButton:hover {
    background: #884743;
}

QPushButton#NavButton {
    background: transparent;
    color: #ffffff;
    border: 2px solid transparent;
    padding: 10px 12px;
    text-align: left;
    font-size: 11.5pt;
}

QPushButton#NavButton:hover {
    background: #2e312b;
    color: #ffffff;
    border-color: #161713;
}

QPushButton#NavButton:checked {
    background: #3d4c32;
    color: #ffffff;
    border-color: #11130f;
}

QLineEdit, QComboBox, QSpinBox, QTextEdit {
    background: #20221f;
    color: #ffffff;
    border: 2px solid #11120f;
    padding: 7px 9px;
    selection-background-color: #688f4d;
}

QSpinBox, QDoubleSpinBox {
    padding-left: 10px;
}

QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QTextEdit:focus {
    border-color: #83b75f;
}

QComboBox::drop-down {
    border: none;
    width: 24px;
}

QComboBox QAbstractItemView {
    background: #252823;
    color: #ffffff;
    border: 2px solid #11120f;
    selection-background-color: #4f6d3c;
}

QCheckBox {
    spacing: 8px;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
    background: #20221f;
    border: 2px solid #10110f;
}

QCheckBox::indicator:checked {
    background: #7eaf59;
    border: 3px solid #10110f;
}

QLabel#MemoryValueLabel {
    color: #ffffff;
    font-weight: 800;
}

QSlider::groove:horizontal {
    height: 10px;
    background: #171915;
    border: 2px solid #0d0e0c;
}

QSlider::sub-page:horizontal {
    background: #6f9f52;
    border: 2px solid #0d0e0c;
}

QSlider::add-page:horizontal {
    background: #292c27;
    border: 2px solid #0d0e0c;
}

QSlider::handle:horizontal {
    width: 20px;
    margin: -7px 0;
    background: #b7e784;
    border: 3px solid #11130f;
}

QSlider::handle:horizontal:hover {
    background: #d0f4a8;
}

QSlider::tick-mark:horizontal {
    background: #8b8d84;
}

QProgressBar {
    background: #11120f;
    color: #ffffff;
    border: 2px solid #090a08;
    min-height: 18px;
    text-align: center;
    font-weight: 700;
}

QProgressBar::chunk {
    background: #77a957;
}

QTextEdit#LogOutput {
    background: #141613;
    color: #ffffff;
    font-size: 10pt;
}

QScrollBar:vertical {
    background: #1b1d1a;
    width: 14px;
    border-left: 2px solid #10110f;
}

QScrollBar::handle:vertical {
    background: #51564c;
    min-height: 28px;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}

QScrollBar:horizontal {
    background: #1b1d1a;
    height: 14px;
    border-top: 2px solid #10110f;
}

QScrollBar::handle:horizontal {
    background: #51564c;
    min-width: 28px;
}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}

QTableWidget, QPlainTextEdit {
    background: #20221f;
    color: #ffffff;
    border: 2px solid #11120f;
    gridline-color: #11120f;
    selection-background-color: #4f6d3c;
    selection-color: #ffffff;
}

QHeaderView::section {
    background: #343730;
    color: #ffffff;
    border: 1px solid #11120f;
    padding: 7px;
    font-weight: 800;
}

QTableWidget::item {
    padding: 5px;
}

QFrame#ToastNotification {
    background: #252823;
    border: 2px solid #11130f;
    border-radius: 6px;
}

QFrame#ToastNotification[toastLevel="success"] {
    border-color: #77a957;
}

QFrame#ToastNotification[toastLevel="warning"] {
    border-color: #d8a84f;
}

QFrame#ToastNotification[toastLevel="error"] {
    border-color: #c45c5c;
}

QLabel#ToastTitle {
    color: #ffffff;
    font-weight: 800;
}

QLabel#ToastMessage {
    color: #d8dbd3;
}

QToolTip {
    background: #252823;
    color: #ffffff;
    border: 2px solid #11120f;
    padding: 5px;
}

QFrame#Sidebar[compactLayout="true"] QLabel#BrandLabel {
    font-size: 18px;
    letter-spacing: 0.5px;
}

QPushButton#NavButton[compactLayout="true"] {
    padding: 6px 8px;
    font-size: 10.5pt;
}

QWidget#PageViewport[compactLayout="true"] QLabel#PageTitle,
QFrame#RightPanel[compactLayout="true"] QLabel#PageTitle {
    font-size: 22px;
}

QWidget#PageViewport[compactLayout="true"] QLabel#PageSubtitle {
    font-size: 10pt;
}

QFrame#RightPanel[compactLayout="true"] QLabel#ValueLabel {
    font-size: 10.5pt;
}

QFrame#RightPanel[compactLayout="true"] QLabel#CardTitle {
    font-size: 12px;
}

QFrame#RightPanel[compactLayout="true"] QPushButton {
    padding: 6px 8px;
}

QFrame#LaunchControl[compactLayout="true"] QLabel#ValueLabel {
    font-size: 10.5pt;
}
"""

APP_STYLE += "\n" + FORCED_DARK_APPLICATION_STYLE
